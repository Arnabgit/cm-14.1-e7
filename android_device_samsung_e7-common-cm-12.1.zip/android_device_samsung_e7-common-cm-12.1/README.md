Device tree for Samsung E7
=================================

This branch is for building CyanogenMod Firmware.
